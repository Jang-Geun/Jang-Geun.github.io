function dydt=npzd_0d_with_forcings(t,y)
    
    Umax=1.0;   % P maximum growth rate
    kn=1.0;     % P half saturation nutrient concentration
    sigma=0.1;  % P mortality rate
    Rm=0.5;     % Z maximum growth rate
    xi=0.15;    % Z mortality rate
    Lambda=1.0; % Z growth saturation parameter
    gamma=0;    % Z grazing ineffienchy
    delta=1.0;  % D remineralization rate
    wH=3.0;     % D sinking rate (speed divded by layer thicknes)
    kI=150;     % P half saturation light intensity
    
    % mixing
    doy=mod(t,360);
    if doy<90 || doy>270 % winter
        A=1.0;
    else % summer
        A=0;
    end
    
    % light intensity
    I=40*sin(2*pi*(t-75)/360)+80;

    % surface variables
    N=y(1);
    P=y(2);
    Z=y(3);
    D=y(4);

    % subsurface variables
    N2=y(5);
    D2=y(6);
    
    U=Umax*N./(N+kn)*I./(I+kI); % phytoplankton growth rate
    G=Rm*(1-exp(-Lambda*P));    % zooplankton growth rate

    dydt(1,1)=-U*P+gamma*G*Z+delta*D-A*(N-N2);    % N
    dydt(2,1)=U*P-sigma*P-G*Z;                    % P
    dydt(3,1)=(1-gamma)*G*Z-xi*Z;                 % Z
    dydt(4,1)=sigma*P+xi*Z-delta*D-wH*D-A*(D-D2); % D

    dydt(5,1)=delta*D2+A*(N-N2);                  % N2
    dydt(6,1)=wH*D-delta*D2+A*(D-D2);             % D2
    
end