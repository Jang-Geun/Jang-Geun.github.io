clc;clear;

[t,y]=ode45(@npzd_0d_with_forcings,[0 720],[5 0.1 0.1 0.1 0 0]);

plot(t,y)
hold on
plot(t,sum(y,2),'k')
legend('N','P','Z','D','N2','D2','N_T')
