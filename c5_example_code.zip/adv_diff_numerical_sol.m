% Simple 1D ecosystem model template - advection-diffusion equation

% Choi et al. (2024). A new ecosystem model for Arctic phytoplankton
% phenology from ice‐covered to open‐water periods: Implications for
% future sea ice retreat scenarios. Geophysical Research Letters, 51(19),
% e2024GL110155.
%
% Choi, J.-G. (2024). One-dimensional Arctic Ocean Ecosystem model (v1.0). 
% Zenodo. https://doi.org/10.5281/zenodo.13346090

clc;clear;%close all

h=100;               % total depth
dt=10;               % time step
nb=1;                % number of tracers
nz=201;              % number of grids
nt=1500/dt;          % number of steps for simulations
nr=1;                % number of steps for record freqeuncy

% set-up grid
zr=linspace(-h,0,nz)';
zu=convn(zr,[.5;.5],'valid');
dz=mean(diff(zr));

C=zeros(nz,2,nb);

% set-up initial conditions
C(:,1,1)=exp(-((zr+h/2)/5).^2); % D

B=zeros(nz,floor(nt/nr),nb);
t=zeros(1,floor(nt/nr));

% parameters
wd=-0.05;
Ai=zu*0+0.05;

tic
for j=1:nt+1

    %% I/O
    if any(isnan(C(:)))
        error('model blow-up')
    end
    
    if mod(j-1,nr)==0
        B(:,(j-1)/nr+1,:)=C(:,1,:);
        t((j-1)/nr+1)=dt*(j-1);
    end

    %% Reaction terms (detritus remineralization)

    %% physical processes
    % vertical diffusion (implicit scheme)
    Af=[0;Ai;0];
    alp=dt/dz^2;
    F=spdiags([-alp*Af(2:end) alp*conv(Af,[1 1],'valid')+1 -alp*Af(1:end-1)],-1:1,nz,nz);
    for i=1:size(C,3)
        C(:,2,i)=F\C(:,1,i);
    end
    C(:,1,:)=C(:,2,:);

    % vertical advection 
    for idS=1
        % setup vertical velocity fields
        ws=wd*ones(size(zu));

        % upwind
        i=1;  % bottom B.C.
        if ws(i)<0
            C(i,2,idS)=C(i,1,idS)-dt/dz*ws(i)*C(i+1,1,idS);
        else
            C(i,2,idS)=C(i,1,idS)-dt/dz*ws(i)*C(i,1,idS);
        end
        i=nz; % surface B.C.
        if ws(i-1)<0
            C(i,2,idS)=C(i,1,idS)+dt/dz*ws(i-1)*C(i,1,idS);
        else
            C(i,2,idS)=C(i,1,idS)+dt/dz*ws(i-1)*C(i-1,1,idS);
        end
        % interior
        C(2:end-1,2,idS)=C(2:end-1,1,idS)-dt/dz*(...
            min(ws(2:end),0).*C(3:end,1,idS)-min(ws(1:end-1),0).*C(2:end-1,1,idS)...
           +max(ws(2:end),0).*C(2:end-1,1,idS)-max(ws(1:end-1),0).*C(1:end-2,1,idS));
        C(:,1,idS)=C(:,2,idS);
    end

end