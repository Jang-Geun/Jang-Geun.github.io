clc;clear;

% solving ODE: dy/dt=Unet*y
y0=1;
[t,y]=ode23(@exp_model1,[0 30],y0);
plot(t,y)

% solving ODE system: d[A;B]/dt=[-a*A;a*A]
% that representing dA/dt=-a*A and dB/dt=a*A
% In this case, I made separate file for the model (see exp_model2.m)
A0=1; % initial A
B0=0; % initial B
t=0:0.1:30;
[~,y]=ode45(@exp_model2,t,[A0 B0]);
A=y(:,1);
B=y(:,2);
plot(t,A)
hold on
plot(t,B)
legend('A','B')

function dydt=exp_model1(t,y)
Unet=-0.1;
dydt=Unet*y;
end

