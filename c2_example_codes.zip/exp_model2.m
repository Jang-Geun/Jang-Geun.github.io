function dydt=exp_model2(t,y)
a=0.1;
A=y(1);
B=y(2);

dydt(1,1)=-a*A;
dydt(2,1)=a*A;
end