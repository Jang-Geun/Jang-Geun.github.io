clc;clear;

global dx dy dt nx ny
 
L=2; 
x1=linspace(-L,L,150);
y1=linspace(-L,L,151);
[y,x]=meshgrid(y1,x1);
 
xu1=conv(x1,[0.5 0.5],'valid');
yu1=y1;
xv1=x1;
yv1=conv(y1,[0.5 0.5],'valid');
 
[yu,xu]=meshgrid(yu1,xu1);
[yv,xv]=meshgrid(yv1,xv1);

eta=exp(-(x.^2+y.^2));
v=-2*xv.*exp(-(xv.^2+yv.^2));
u=2*yu.*exp(-(xu.^2+yu.^2));
 
dx=mean(diff(x1));
dy=mean(diff(y1));
dt=0.0125;
nx=size(x,1);
ny=size(y,2);
 
 
n=5/dt;
c=zeros(nx,ny,n);
c=exp(-((x+1).^2+y.^2)/(1/4)^2);
t=0;
for i=1:n
    t(i+1)=t(i)+dt;
    % advection
    c(:,:,i+1)=c(:,:,i)-dt*Adv(u,v,c(:,:,i));
    
    c(:,1,i+1)=0;
    c(:,end,i+1)=0;
    c(1,:,i+1)=0;
    c(end,:,i+1)=0;
end


% vis.
figure
pcolor(x,y,c(:,:,end))
shading flat
xlabel('x'); ylabel('y')
axis equal
axis([-2 2 -2 2])
set(gca,'FontSize',15,'FontName','times new roman')
cb=colorbar;
ylabel(cb,'C')
set(gca,'YTick',-2:1:2)
title(['t=' num2str(t(end),'%3.2f')])

my_print('fig_numerical_sol_euler')

%% animation
% for i=1:size(c,3)
%     contourf(x,y,c(:,:,i))
%     drawnow
% end
% 
% save('geo_advection_eulerian.mat','x','y','t','c')