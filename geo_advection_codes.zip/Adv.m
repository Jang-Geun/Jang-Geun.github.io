function adv=Adv(u,v,c)

global dx dy dt nx ny

adv=zeros(nx,ny);
rxp=zeros(size(u));
rxn=zeros(size(u));
ryp=zeros(size(v));
ryn=zeros(size(v));

for i=2:nx-2
    for j=2:ny-2
        rxp(i,j)=(c(i,j)-c(i-1,j))./(c(i+1,j)-c(i,j));
        rxn(i,j)=(c(i+2,j)-c(i+1,j))./(c(i+1,j)-c(i,j));
        ryp(i,j)=(c(i,j)-c(i,j-1))./(c(i,j+1)-c(i,j));
        ryn(i,j)=(c(i,j+2)-c(i,j+1))./(c(i,j+1)-c(i,j));
    end
end

rxp(isnan(rxp))=0;
rxn(isnan(rxn))=0;
rxp(isinf(rxp))=0;
rxn(isinf(rxn))=0;

ryp(isnan(ryp))=0;
ryn(isnan(ryn))=0;
ryp(isinf(ryp))=0;
ryn(isinf(ryn))=0;

for i=2:nx-1
    for j=2:ny-1
        uep=(u(i,j)+abs(u(i,j)))/2;
        uen=(u(i,j)-abs(u(i,j)))/2;
        uwp=(u(i-1,j)+abs(u(i-1,j)))/2;
        uwn=(u(i-1,j)-abs(u(i-1,j)))/2;

        unp=(v(i,j)+abs(v(i,j)))/2;
        unn=(v(i,j)-abs(v(i,j)))/2;
        usp=(v(i,j-1)+abs(v(i,j-1)))/2;
        usn=(v(i,j-1)-abs(v(i,j-1)))/2;


        cep=c(i,j)...
            +0.5*Psi(rxp(i,j))*(1-dt/dx*uep)*(c(i+1,j)-c(i,j));
        cen=c(i+1,j)...
            -0.5*Psi(rxn(i,j))*(1+dt/dx*uen)*(c(i+1,j)-c(i,j));
        cwp=c(i-1,j)...
            +0.5*Psi(rxp(i-1,j))*(1-dt/dx*uwp)*(c(i,j)-c(i-1,j));
        cwn=c(i,j)...
            -0.5*Psi(rxn(i-1,j))*(1+dt/dx*uwn)*(c(i,j)-c(i-1,j));

        cnp=c(i,j)...
            +0.5*Psi(ryp(i,j))*(1-dt/dy*unp)*(c(i,j+1)-c(i,j));
        cnn=c(i,j+1)...
            -0.5*Psi(ryn(i,j))*(1+dt/dy*unn)*(c(i,j+1)-c(i,j));
        csp=c(i,j-1)...
            +0.5*Psi(ryp(i,j-1))*(1-dt/dy*usp)*(c(i,j)-c(i,j-1));
        csn=c(i,j)...
            -0.5*Psi(ryn(i,j-1))*(1+dt/dy*usn)*(c(i,j)-c(i,j-1));
        adv(i,j)=(uep*cep+uen*cen-uwp*cwp-uwn*cwn)/dx+...
            (unp*cnp+unn*cnn-usp*csp-usn*csn)/dy;
    end
end
