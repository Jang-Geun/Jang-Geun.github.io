% Simple numerical experiment code solving transport (advection) in
% Lagrangian point of view.
clc;clear;
%% setup velocity field and grids
syms x y
eta=exp(-(x.^2+y.^2)); % eta0/L~1
u=-diff(eta,y);        % g/f~1
v=diff(eta,x);         % g/f~1

etaf=matlabFunction(eta);

global uf vf
uf=matlabFunction(u);
vf=matlabFunction(v);

% grid
x1=linspace(-2,2,32);
y1=linspace(-2,2,32);
[y2,x2]=meshgrid(y1,x1);

% vis.
figure
contourf(x2,y2,etaf(x2,y2))
hold on
quiver(x2(1:2:end,1:2:end),y2(1:2:end,1:2:end), ...
    uf(x2(1:2:end,1:2:end),y2(1:2:end,1:2:end)), ...
    vf(x2(1:2:end,1:2:end),y2(1:2:end,1:2:end)),'k')
xlabel('x'); ylabel('y')
axis equal
set(gca,'FontSize',15,'FontName','times new roman')
cb=colorbar;
ylabel(cb,'\eta')
set(gca,'YTick',-2:1:2)

my_print('fig_velo_field')
%% setup initial conditions

% number of particles
N=4e4;

% initial position (random distribution)
X0=(rand(1,N)*4)-2;     % initial x-position
Y0=(rand(1,N)*4)-2;     % initial y-position

% initial value (e.g., concentration)
c=exp(-((x+1).^2+y.^2)/(1/4)^2);
Cf=matlabFunction(c);
C0=Cf(X0,Y0);            % initial c-value
idmax=find(C0==max(C0)); % index of tracking particle

% vis.
figure
scatter(X0,Y0,[],C0,'.')
xlabel('x'); ylabel('y')
axis equal
axis([-2 2 -2 2])
set(gca,'FontSize',15,'FontName','times new roman')
cb=colorbar;
ylabel(cb,'C')
set(gca,'YTick',-2:1:2)

my_print('fig_ini_condition')
%% solving equations
t=0:0.025:5;
tic
[~,xyc]=ode45(@(t,y)uvc_vectorize(t,y,N) ...
    ,t,[X0;Y0;C0]);
xyc = reshape(xyc,[],N);

nt=length(t);
X=xyc(0*nt+1:1*nt,:);
Y=xyc(1*nt+1:2*nt,:);
C=xyc(2*nt+1:3*nt,:);
t1=toc;

% % above codes are identical to below codes, but vectorized form much
% % faters.
% tic
% X=zeros(length(t),nn);
% Y=zeros(length(t),nn);
% C=zeros(length(t),nn);
% for i=1:nn
% [~,xyc]=ode45(@uv,t,[X0(i) Y0(i) C0(i)]);
% X(:,i)=xyc(:,1);
% Y(:,i)=xyc(:,2);
% C(:,i)=xyc(:,3);
% end
% t2=toc;

% vis.
figure
scatter(X(end,:),Y(end,:),[],C(end,:),'.')
xlabel('x'); ylabel('y')
axis equal
axis([-2 2 -2 2])
set(gca,'FontSize',15,'FontName','times new roman')
cb=colorbar;
ylabel(cb,'C')
set(gca,'YTick',-2:1:2)
title(['t=' num2str(t(end),'%3.2f')])

my_print('fig_numerical_sol')

%% generate gif

ll=0.15;
ax=[-ll ll 1-ll 1+ll];
idx=X>ax(1) & X<ax(2) &Y>ax(3) &Y<ax(4);
ce=(double(idx)*(C0'))./sum(idx,2);
etaid=etaf(X(:,idmax),Y(:,idmax));


fig = figure;
set(gcf,'Color','w')
filename = "geo_advection.gif";

set(gcf,'Position',[1000 458 560*3/2 420])
for i=1:length(t)
    subplot(2,2,[1 3])
    scatter(X(i,:),Y(i,:),[],C0,'.')
    hold on
    scatter(X(i,idmax),Y(i,idmax),[],C0(idmax),'o','filled','MarkerEdgeColor','r')
    plot(ax([1 1]),ax([3 4]),'r','LineWidth',1.5)
    plot(ax([2 2]),ax([3 4]),'r','LineWidth',1.5)
    plot(ax([1 2]),ax([3 3]),'r','LineWidth',1.5)
    plot(ax([1 2]),ax([4 4]),'r','LineWidth',1.5)
    hold off
    title(['t=' num2str(t(i),'%3.2f')])
    axis equal
    axis([-2 2 -2 2])
    set(gca,'FontSize',15,'FontName','times new roman')
    xlabel('x')
    ylabel('y')

    subplot(2,2,2)
    plot(t,ce,'LineWidth',2)
    axis([t([1 end]) 0 0.5])
    hold on
    plot(t([i i]),ylim,'r')
    hold off
    ylabel('C')
    set(gca,'FontSize',12,'FontName','times new roman','color','w')
    title('Eulerian (red box)')

    subplot(2,2,4)
    plot(t([1 end]),C0([idmax idmax]),'LineWidth',2)
    axis([t([1 end]) 0 1.4])
    hold on
    plot(t,etaid,'LineWidth',2)
    plot(t([i i]),ylim,'r')
    hold off
    xlabel('t')
    ylabel('C or \eta')
    set(gca,'FontSize',12,'FontName','times new roman','color','w')
    legend('C','\eta','numcolumns',2,'box','off')
    title('Lagrangian (red circle)')

    drawnow

    frame = getframe(fig);
    im{i} = frame2im(frame);
    [An,map] = rgb2ind(im{i},256);
    if i == 1
        imwrite(An,map,filename,"gif",LoopCount=Inf, ...
                DelayTime=0.04)
    else
        imwrite(An,map,filename,"gif",WriteMode="append", ...
                DelayTime=0.04)
    end
end

% Xfin=X(end,:);
% Yfin=Y(end,:);
% Cfin=C(end,:);
% save('geo_advection.mat','Xfin','Yfin','Cfin') 