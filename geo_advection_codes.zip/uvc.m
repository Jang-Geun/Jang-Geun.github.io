function dydt=uvc(~,y)
global uf vf
X=y(1);
Y=y(2);
C=y(3);

dydt(1,1)=uf(X,Y);
dydt(2,1)=vf(X,Y);
dydt(3,1)=0;
end