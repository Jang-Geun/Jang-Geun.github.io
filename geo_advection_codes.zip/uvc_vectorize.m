function dydt=uvc_vectorize(~,y,n)
global uf vf

y = reshape(y,[],n);

X=y(1,:);
Y=y(2,:);
C=y(3,:);

dydt(1,:)=uf(X,Y);
dydt(2,:)=vf(X,Y);
dydt(3,:)=0;

dydt=dydt(:);
end