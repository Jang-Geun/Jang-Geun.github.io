function p=Psi(r)
%     % upwind scheme
%     p=0;
%     % Lax-Wendroff scheme
%     p=1;
    % superbee scheme
    p=max([0, min([2*r,1]) min([r,2])]);
