clc;clear;

%% example of vector field
% true field generation
syms x y

psif=3*(1-x).^2.*exp(-(x.^2) - (y+1).^2) ... 
  - 10*(x/5 - x.^3 - y.^5).*exp(-x.^2-y.^2) ... 
  - 1/3*exp(-(x+1).^2 - y.^2); % peaks
psif=psif+3*x;

v_sol=matlabFunction(diff(psif,x));
u_sol=matlabFunction(-diff(psif,y));

nx=50;
ny=49;
xi=linspace(-3,3,nx);
yi=linspace(-3,3,ny);
[y,x]=meshgrid(yi,xi);

% sample data
psi_sol=matlabFunction(psif);
psi=psi_sol(x,y);
u=u_sol(x,y);
v=v_sol(x,y);

save('c1_lab1_uv','u','v','psi','x','y')

contourf(x,y,psi)
ax=axis;
hold on
quiver(x,y,u,v,'k')
axis(ax);

set(gcf,'Position',[680 458 560 420])
fontsize(13,'points')
fontname('Times New Roman')
xlabel('x');
ylabel('y');

my_print('lab_velo_field1')